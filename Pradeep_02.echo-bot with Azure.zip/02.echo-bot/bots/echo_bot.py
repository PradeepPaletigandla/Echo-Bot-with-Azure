# Copyright (c) Microsoft Corporation. 
# Licensed under the MIT License.

from botbuilder.core import ActivityHandler, TurnContext

class EchoBot(ActivityHandler):
    def __init__(self, text_analytics_client):
        # Azure AI Language client passed from app.py
        self.text_analytics_client = text_analytics_client

    async def on_message_activity(self, turn_context: TurnContext):
        user_text = turn_context.activity.text

        # -----------------------------
        # Handle empty or malformed input
        # -----------------------------
        if not user_text or len(user_text.strip()) < 2:
            await turn_context.send_activity(
                "I didn’t understand that. Try typing a full sentence."
            )
            return

        # -----------------------------
        # Friendly greeting
        # -----------------------------
        if user_text.lower() in ["hi", "hello", "hey"]:
            await turn_context.send_activity(
                "Hello! I can analyze sentiment. Try typing a sentence."
            )
            return

        # -----------------------------
        # Capabilities command
        # -----------------------------
        if user_text.lower() in ["help", "capabilities"]:
            await turn_context.send_activity(
                "I can:\n"
                "- Echo your message\n"
                "- Analyze sentiment using Azure AI Language\n"
                "- Handle malformed or empty input\n"
                "- Provide friendly responses"
            )
            return

        # -----------------------------
        # Azure Sentiment Analysis
        # -----------------------------
        try:
            documents = [user_text]
            response = self.text_analytics_client.analyze_sentiment(documents=documents)[0]

            sentiment = response.sentiment
            scores = response.confidence_scores

            reply = (
                f"You said: {user_text}\n\n"
                f"Sentiment: {sentiment}\n"
                f"Scores → Positive: {scores.positive:.2f}, "
                f"Neutral: {scores.neutral:.2f}, "
                f"Negative: {scores.negative:.2f}"
            )

            await turn_context.send_activity(reply)

        except Exception as e:
            # If Azure API fails
            await turn_context.send_activity(
                "I couldn't analyze sentiment due to an internal error."
            )
            await turn_context.send_activity(str(e))
