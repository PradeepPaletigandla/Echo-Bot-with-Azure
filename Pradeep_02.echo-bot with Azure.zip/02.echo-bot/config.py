#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.


import os

class DefaultConfig:
    PORT = 3978

    # Azure AI Language settings
    API_KEY = os.environ.get("MicrosoftAPIKey")
    ENDPOINT_URI = os.environ.get("MicrosoftAIServiceEndpoint")
